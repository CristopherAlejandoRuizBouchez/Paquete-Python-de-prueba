def suma(a, b):

    return a - b

resultado = suma(5, 3)
print("El resultado de la resta es:", resultado)